/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xc3576ebc */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "E:/eda/key_board/key_scan.v";
static int ng1[] = {0, 0};
static unsigned int ng2[] = {14U, 0U};
static int ng3[] = {1, 0};
static unsigned int ng4[] = {13U, 0U};
static int ng5[] = {2, 0};
static unsigned int ng6[] = {11U, 0U};
static int ng7[] = {3, 0};
static unsigned int ng8[] = {7U, 0U};
static unsigned int ng9[] = {1003U, 0U};
static unsigned int ng10[] = {0U, 0U};
static unsigned int ng11[] = {503U, 0U};
static unsigned int ng12[] = {1U, 0U};
static unsigned int ng13[] = {507U, 0U};
static unsigned int ng14[] = {2U, 0U};
static unsigned int ng15[] = {509U, 0U};
static unsigned int ng16[] = {3U, 0U};
static unsigned int ng17[] = {759U, 0U};
static unsigned int ng18[] = {4U, 0U};
static unsigned int ng19[] = {763U, 0U};
static unsigned int ng20[] = {5U, 0U};
static unsigned int ng21[] = {765U, 0U};
static unsigned int ng22[] = {6U, 0U};
static unsigned int ng23[] = {887U, 0U};
static unsigned int ng24[] = {891U, 0U};
static unsigned int ng25[] = {8U, 0U};
static unsigned int ng26[] = {893U, 0U};
static unsigned int ng27[] = {9U, 0U};
static unsigned int ng28[] = {894U, 0U};
static unsigned int ng29[] = {10U, 0U};
static unsigned int ng30[] = {510U, 0U};
static unsigned int ng31[] = {15U, 0U};



static void Cont_33_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    unsigned int t13;
    unsigned int t14;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;

LAB0:    t1 = (t0 + 3168U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(33, ng0);
    t2 = (t0 + 1928);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 4360);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memset(t9, 0, 8);
    t10 = 15U;
    t11 = t10;
    t12 = (t4 + 4);
    t13 = *((unsigned int *)t4);
    t10 = (t10 & t13);
    t14 = *((unsigned int *)t12);
    t11 = (t11 & t14);
    t15 = (t9 + 4);
    t16 = *((unsigned int *)t9);
    *((unsigned int *)t9) = (t16 | t10);
    t17 = *((unsigned int *)t15);
    *((unsigned int *)t15) = (t17 | t11);
    xsi_driver_vfirst_trans(t5, 0, 3);
    t18 = (t0 + 4232);
    *((int *)t18) = 1;

LAB1:    return;
}

static void Cont_35_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    unsigned int t13;
    unsigned int t14;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;

LAB0:    t1 = (t0 + 3416U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(35, ng0);
    t2 = (t0 + 2248);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 4424);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memset(t9, 0, 8);
    t10 = 15U;
    t11 = t10;
    t12 = (t4 + 4);
    t13 = *((unsigned int *)t4);
    t10 = (t10 & t13);
    t14 = *((unsigned int *)t12);
    t11 = (t11 & t14);
    t15 = (t9 + 4);
    t16 = *((unsigned int *)t9);
    *((unsigned int *)t9) = (t16 | t10);
    t17 = *((unsigned int *)t15);
    *((unsigned int *)t15) = (t17 | t11);
    xsi_driver_vfirst_trans(t5, 0, 3);
    t18 = (t0 + 4248);
    *((int *)t18) = 1;

LAB1:    return;
}

static void Always_39_2(char *t0)
{
    char t8[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    char *t23;
    char *t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    char *t30;
    char *t31;

LAB0:    t1 = (t0 + 3664U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(39, ng0);
    t2 = (t0 + 4264);
    *((int *)t2) = 1;
    t3 = (t0 + 3696);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(40, ng0);
    t4 = (t0 + 2088);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = ((char*)((ng1)));
    memset(t8, 0, 8);
    t9 = (t6 + 4);
    t10 = (t7 + 4);
    t11 = *((unsigned int *)t6);
    t12 = *((unsigned int *)t7);
    t13 = (t11 ^ t12);
    t14 = *((unsigned int *)t9);
    t15 = *((unsigned int *)t10);
    t16 = (t14 ^ t15);
    t17 = (t13 | t16);
    t18 = *((unsigned int *)t9);
    t19 = *((unsigned int *)t10);
    t20 = (t18 | t19);
    t21 = (~(t20));
    t22 = (t17 & t21);
    if (t22 != 0)
        goto LAB8;

LAB5:    if (t20 != 0)
        goto LAB7;

LAB6:    *((unsigned int *)t8) = 1;

LAB8:    t24 = (t8 + 4);
    t25 = *((unsigned int *)t24);
    t26 = (~(t25));
    t27 = *((unsigned int *)t8);
    t28 = (t27 & t26);
    t29 = (t28 != 0);
    if (t29 > 0)
        goto LAB9;

LAB10:    xsi_set_current_line(45, ng0);
    t2 = (t0 + 2088);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng3)));
    memset(t8, 0, 8);
    t6 = (t4 + 4);
    t7 = (t5 + 4);
    t11 = *((unsigned int *)t4);
    t12 = *((unsigned int *)t5);
    t13 = (t11 ^ t12);
    t14 = *((unsigned int *)t6);
    t15 = *((unsigned int *)t7);
    t16 = (t14 ^ t15);
    t17 = (t13 | t16);
    t18 = *((unsigned int *)t6);
    t19 = *((unsigned int *)t7);
    t20 = (t18 | t19);
    t21 = (~(t20));
    t22 = (t17 & t21);
    if (t22 != 0)
        goto LAB16;

LAB13:    if (t20 != 0)
        goto LAB15;

LAB14:    *((unsigned int *)t8) = 1;

LAB16:    t10 = (t8 + 4);
    t25 = *((unsigned int *)t10);
    t26 = (~(t25));
    t27 = *((unsigned int *)t8);
    t28 = (t27 & t26);
    t29 = (t28 != 0);
    if (t29 > 0)
        goto LAB17;

LAB18:    xsi_set_current_line(50, ng0);
    t2 = (t0 + 2088);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng5)));
    memset(t8, 0, 8);
    t6 = (t4 + 4);
    t7 = (t5 + 4);
    t11 = *((unsigned int *)t4);
    t12 = *((unsigned int *)t5);
    t13 = (t11 ^ t12);
    t14 = *((unsigned int *)t6);
    t15 = *((unsigned int *)t7);
    t16 = (t14 ^ t15);
    t17 = (t13 | t16);
    t18 = *((unsigned int *)t6);
    t19 = *((unsigned int *)t7);
    t20 = (t18 | t19);
    t21 = (~(t20));
    t22 = (t17 & t21);
    if (t22 != 0)
        goto LAB24;

LAB21:    if (t20 != 0)
        goto LAB23;

LAB22:    *((unsigned int *)t8) = 1;

LAB24:    t10 = (t8 + 4);
    t25 = *((unsigned int *)t10);
    t26 = (~(t25));
    t27 = *((unsigned int *)t8);
    t28 = (t27 & t26);
    t29 = (t28 != 0);
    if (t29 > 0)
        goto LAB25;

LAB26:    xsi_set_current_line(56, ng0);

LAB29:    xsi_set_current_line(57, ng0);
    t2 = ((char*)((ng8)));
    t3 = (t0 + 1928);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 4, 0LL);
    xsi_set_current_line(58, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 2088);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 2, 0LL);

LAB27:
LAB19:
LAB11:    goto LAB2;

LAB7:    t23 = (t8 + 4);
    *((unsigned int *)t8) = 1;
    *((unsigned int *)t23) = 1;
    goto LAB8;

LAB9:    xsi_set_current_line(41, ng0);

LAB12:    xsi_set_current_line(42, ng0);
    t30 = ((char*)((ng2)));
    t31 = (t0 + 1928);
    xsi_vlogvar_wait_assign_value(t31, t30, 0, 0, 4, 0LL);
    xsi_set_current_line(43, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 2088);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 2, 0LL);
    goto LAB11;

LAB15:    t9 = (t8 + 4);
    *((unsigned int *)t8) = 1;
    *((unsigned int *)t9) = 1;
    goto LAB16;

LAB17:    xsi_set_current_line(46, ng0);

LAB20:    xsi_set_current_line(47, ng0);
    t23 = ((char*)((ng4)));
    t24 = (t0 + 1928);
    xsi_vlogvar_wait_assign_value(t24, t23, 0, 0, 4, 0LL);
    xsi_set_current_line(48, ng0);
    t2 = ((char*)((ng5)));
    t3 = (t0 + 2088);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 2, 0LL);
    goto LAB19;

LAB23:    t9 = (t8 + 4);
    *((unsigned int *)t8) = 1;
    *((unsigned int *)t9) = 1;
    goto LAB24;

LAB25:    xsi_set_current_line(51, ng0);

LAB28:    xsi_set_current_line(52, ng0);
    t23 = ((char*)((ng6)));
    t24 = (t0 + 1928);
    xsi_vlogvar_wait_assign_value(t24, t23, 0, 0, 4, 0LL);
    xsi_set_current_line(53, ng0);
    t2 = ((char*)((ng7)));
    t3 = (t0 + 2088);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 2, 0LL);
    goto LAB27;

}

static void Always_65_3(char *t0)
{
    char t4[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    int t10;
    char *t11;
    char *t12;

LAB0:    t1 = (t0 + 3912U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(65, ng0);
    t2 = (t0 + 4280);
    *((int *)t2) = 1;
    t3 = (t0 + 3944);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(66, ng0);
    t5 = (t0 + 1928);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t0 + 1208U);
    t9 = *((char **)t8);
    xsi_vlogtype_concat(t4, 10, 10, 2U, t9, 6, t7, 4);

LAB5:    t8 = ((char*)((ng9)));
    t10 = xsi_vlog_unsigned_case_compare(t4, 10, t8, 10);
    if (t10 == 1)
        goto LAB6;

LAB7:    t2 = ((char*)((ng11)));
    t10 = xsi_vlog_unsigned_case_compare(t4, 10, t2, 10);
    if (t10 == 1)
        goto LAB8;

LAB9:    t2 = ((char*)((ng13)));
    t10 = xsi_vlog_unsigned_case_compare(t4, 10, t2, 10);
    if (t10 == 1)
        goto LAB10;

LAB11:    t2 = ((char*)((ng15)));
    t10 = xsi_vlog_unsigned_case_compare(t4, 10, t2, 10);
    if (t10 == 1)
        goto LAB12;

LAB13:    t2 = ((char*)((ng17)));
    t10 = xsi_vlog_unsigned_case_compare(t4, 10, t2, 10);
    if (t10 == 1)
        goto LAB14;

LAB15:    t2 = ((char*)((ng19)));
    t10 = xsi_vlog_unsigned_case_compare(t4, 10, t2, 10);
    if (t10 == 1)
        goto LAB16;

LAB17:    t2 = ((char*)((ng21)));
    t10 = xsi_vlog_unsigned_case_compare(t4, 10, t2, 10);
    if (t10 == 1)
        goto LAB18;

LAB19:    t2 = ((char*)((ng23)));
    t10 = xsi_vlog_unsigned_case_compare(t4, 10, t2, 10);
    if (t10 == 1)
        goto LAB20;

LAB21:    t2 = ((char*)((ng24)));
    t10 = xsi_vlog_unsigned_case_compare(t4, 10, t2, 10);
    if (t10 == 1)
        goto LAB22;

LAB23:    t2 = ((char*)((ng26)));
    t10 = xsi_vlog_unsigned_case_compare(t4, 10, t2, 10);
    if (t10 == 1)
        goto LAB24;

LAB25:    t2 = ((char*)((ng28)));
    t10 = xsi_vlog_unsigned_case_compare(t4, 10, t2, 10);
    if (t10 == 1)
        goto LAB26;

LAB27:    t2 = ((char*)((ng30)));
    t10 = xsi_vlog_unsigned_case_compare(t4, 10, t2, 10);
    if (t10 == 1)
        goto LAB28;

LAB29:
LAB31:
LAB30:    xsi_set_current_line(79, ng0);
    t2 = ((char*)((ng31)));
    t3 = (t0 + 2248);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 4, 0LL);

LAB32:    goto LAB2;

LAB6:    xsi_set_current_line(67, ng0);
    t11 = ((char*)((ng10)));
    t12 = (t0 + 2248);
    xsi_vlogvar_wait_assign_value(t12, t11, 0, 0, 4, 0LL);
    goto LAB32;

LAB8:    xsi_set_current_line(68, ng0);
    t3 = ((char*)((ng12)));
    t5 = (t0 + 2248);
    xsi_vlogvar_wait_assign_value(t5, t3, 0, 0, 4, 0LL);
    goto LAB32;

LAB10:    xsi_set_current_line(69, ng0);
    t3 = ((char*)((ng14)));
    t5 = (t0 + 2248);
    xsi_vlogvar_wait_assign_value(t5, t3, 0, 0, 4, 0LL);
    goto LAB32;

LAB12:    xsi_set_current_line(70, ng0);
    t3 = ((char*)((ng16)));
    t5 = (t0 + 2248);
    xsi_vlogvar_wait_assign_value(t5, t3, 0, 0, 4, 0LL);
    goto LAB32;

LAB14:    xsi_set_current_line(71, ng0);
    t3 = ((char*)((ng18)));
    t5 = (t0 + 2248);
    xsi_vlogvar_wait_assign_value(t5, t3, 0, 0, 4, 0LL);
    goto LAB32;

LAB16:    xsi_set_current_line(72, ng0);
    t3 = ((char*)((ng20)));
    t5 = (t0 + 2248);
    xsi_vlogvar_wait_assign_value(t5, t3, 0, 0, 4, 0LL);
    goto LAB32;

LAB18:    xsi_set_current_line(73, ng0);
    t3 = ((char*)((ng22)));
    t5 = (t0 + 2248);
    xsi_vlogvar_wait_assign_value(t5, t3, 0, 0, 4, 0LL);
    goto LAB32;

LAB20:    xsi_set_current_line(74, ng0);
    t3 = ((char*)((ng8)));
    t5 = (t0 + 2248);
    xsi_vlogvar_wait_assign_value(t5, t3, 0, 0, 4, 0LL);
    goto LAB32;

LAB22:    xsi_set_current_line(75, ng0);
    t3 = ((char*)((ng25)));
    t5 = (t0 + 2248);
    xsi_vlogvar_wait_assign_value(t5, t3, 0, 0, 4, 0LL);
    goto LAB32;

LAB24:    xsi_set_current_line(76, ng0);
    t3 = ((char*)((ng27)));
    t5 = (t0 + 2248);
    xsi_vlogvar_wait_assign_value(t5, t3, 0, 0, 4, 0LL);
    goto LAB32;

LAB26:    xsi_set_current_line(77, ng0);
    t3 = ((char*)((ng29)));
    t5 = (t0 + 2248);
    xsi_vlogvar_wait_assign_value(t5, t3, 0, 0, 4, 0LL);
    goto LAB32;

LAB28:    xsi_set_current_line(78, ng0);
    t3 = ((char*)((ng6)));
    t5 = (t0 + 2248);
    xsi_vlogvar_wait_assign_value(t5, t3, 0, 0, 4, 0LL);
    goto LAB32;

}


extern void work_m_00000000004018070369_4101221563_init()
{
	static char *pe[] = {(void *)Cont_33_0,(void *)Cont_35_1,(void *)Always_39_2,(void *)Always_65_3};
	xsi_register_didat("work_m_00000000004018070369_4101221563", "isim/tsw_isim_beh.exe.sim/work/m_00000000004018070369_4101221563.didat");
	xsi_register_executes(pe);
}
